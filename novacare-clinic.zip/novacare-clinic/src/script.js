// Scroll reveal
const items = document.querySelectorAll(".reveal, .stagger");

const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active");
      }
    });
  },
  { threshold: 0.15 }
);

items.forEach(el => observer.observe(el));

// Dark mode toggle
const toggle = document.getElementById("darkToggle");
const body = document.body;

if (localStorage.getItem("darkMode") === "on") {
  body.classList.add("dark");
  toggle.textContent = "☀️";
}

toggle.addEventListener("click", () => {
  body.classList.toggle("dark");
  const isDark = body.classList.contains("dark");
  toggle.textContent = isDark ? "☀️" : "🌙";
  localStorage.setItem("darkMode", isDark ? "on" : "off");
});
